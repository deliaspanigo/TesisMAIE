
# # # Own functions
import fn01_generic as fn01
import fn02_time as fn02
import fn05_str_paths_spected as fn05

import re

# Libraries - v01 
import GOES
import custom_color_palette as ccp
import matplotlib.pyplot as plt
import numpy as np
import cartopy.crs as ccrs
from cartopy.feature import NaturalEarthFeature
from cartopy.feature import ShapelyFeature
import geopandas as gpd

# Libraries - v02
import os
import rioxarray as rxr
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.image import imread
from itertools import compress
from cartopy.mpl.ticker import LatitudeFormatter, LongitudeFormatter
import re
# Funciones
from joblib import Parallel, delayed

from multiprocessing import Pool
import time
import math

from datetime import datetime, timedelta, timezone

# # 
ruta_shapefile_prov_ARG = "01.own_resources/02.vectorial/prov_argentina_malv/prov_argentina_malv.shp"
datos_shapefile_prov_ARG = gpd.read_file(ruta_shapefile_prov_ARG)

# File .nc reprojected (WGS84) on C
def setup_goes16_spi067_LSTF_convert_tiff2png_WGS84Proj_v01(selected_setup):
    principal_dic = {
        
        "dom002": {
           "product_name": "ABI-L2-LSTF",
            "original_format": ".tiff",
            "new_format": ".png",
            "new_tail": "_ppi005_v001_dom002.png",
            "prefix_file_name" : "OR_ABI-L2-LSTF",
            "subfolder_prod_info": "spi067_ABI-L2-LSTF/",
            "subfolder_version": "spi067_ppi005_tiff2png_v001_dom002_WGS84Proj_Celcius/",
            "abrev_name": "LST",
            "abrev_name2": "LSTF",
            "dt_province_limits_arg": True,
            "domain": [-80.0, -50.0, -60.0, -15.0], #[-165.0,15.0,-90.0,90.0],
            "unit_var": "C",
            "min_var": -20.0,
            "max_var":  60.0,
            "mini_step": 1.0,
            "big_step": 10,
            "input_folder": "03.geot_goes16_wgs84Proj_tiff_files/",
            "output_folder": "04.png/"
        }
    }

    return principal_dic[selected_setup]


def convertir_fecha_string(fecha_string, correccion=0):
    # Convertir el string a un objeto datetime
    fecha_utc = datetime.strptime(fecha_string, '%Y/%m/%d %H:%M %Z')

    # Crear un objeto timezone con la corrección
    correccion_utc = timezone(timedelta(hours=correccion))
    fecha_local = fecha_utc.replace(tzinfo=correccion_utc).astimezone(timezone.utc)

    # Cambiar "UTC" por "Local" en el string
    fecha_local_str = fecha_local.strftime('%Y/%m/%d %H:%M Local')

    return fecha_local_str
    
    


def convert_goes16_spi067_LSTF_nc2png_tiff2png_v01_gen01(selected_input_path, selected_output_path,
                                                  plot_me = True, save_me = True, overwrite = False, key_png_setup = None):
    
    print("Start: convert_tiff2png_goes16_spi067_LSTF_v01_gen01()")
    
   
        
    if plot_me or save_me:
        dt_ok = True
        
    if not dt_ok:
        print("Arguments plot_me and save_me are 'False'.") 
        return
    
    # Setup png
    # key_png_setup = "f00"
    selected_png_setup = setup_goes16_spi067_LSTF_convert_tiff2png_WGS84Proj_v01(key_png_setup)
    
    selected_product = selected_png_setup["product_name"]
    abrev_name = selected_png_setup["abrev_name"]
    abrev_name2 = selected_png_setup["abrev_name2"]
    domain = selected_png_setup["domain"]
    unit_var = selected_png_setup["unit_var"]
    min_var = selected_png_setup["min_var"]
    max_var = selected_png_setup["max_var"]
    mini_step = selected_png_setup["mini_step"]
    big_step = selected_png_setup["big_step"]
    dt_province_limits_arg = selected_png_setup["dt_province_limits_arg"]
    
    selected_file_name = os.path.basename(selected_input_path)
    final_date = fn02.str_fulltime_from_filename(selected_file_name, str01 = "G16_s", str02 = "_")
    
    # Import .nc file and setup for more details
    ds = rxr.open_rasterio(selected_input_path, mask_and_scale=True)
    ds[0]  = ds[0].where(ds[0]  != -9999, np.nan)
    CMI = ds[0]
    LonCor = ds["x"]
    LatCor = ds["y"]
    
    
    #  sat = ds.attribute('platform_ID')
    #  sat_info = ds.variable('goes_imager_projection')
    sat = "GOES16"         # Esta bien asi??????? #faltaria que lo tome de los metatados
    sat_info = "epsg4623"  # Esta bien asi???????
    
    
    # # # Setings colours
    # set the colors of the custom palette
    lower_colors = ['maroon','red','darkorange','#ffff00','forestgreen','cyan','royalblue',(148/255,0/255,211/255)]
    lower_colors.reverse()

    lower_palette = [lower_colors, ccp.range(min_var,max_var,mini_step)]


    # pass parameters to the creates_palette module
    # cmap, cmticks, norm, bounds = ccp.creates_palette([lower_palette, upper_palette], extend='both')
    cmap, cmticks, norm, bounds = ccp.creates_palette([lower_palette], extend='both')

    # creating colorbar labels
    ticks = ccp.range(min_var,max_var,big_step)

    
    lon_cen = 360.0+(domain[0]+domain[1])/2.0



    # # # Plot
    # plt.switch_backend('Agg') # Esto es para que en ejecucion en paralelo no haya problemas.
    
    # creates the figure
    fig = plt.figure('map', figsize=(4,4), dpi=200)
    ax = fig.add_axes([0.1, 0.16, 0.80, 0.75], projection=ccrs.PlateCarree(lon_cen))
    # ax.outline_patch.set_linewidth(0.3)

    # add the geographic boundaries
    l = NaturalEarthFeature(category='cultural', name='admin_0_countries', scale='50m', facecolor='none')
    ax.add_feature(l, edgecolor='black', linewidth=0.25)

    # Agregar límites provinciales de Argentina con NaturalEarthFeature
    
    if dt_province_limits_arg:
        # ruta_shapefile = "01.own_resources/02.vectorial/prov_argentina_malv/prov_argentina_malv.shp"
        # datos_shapefile = gpd.read_file(ruta_shapefile)
        datos_shapefile = datos_shapefile_prov_ARG #datos_shapefile_prov_ARG()
        shape_feature = ShapelyFeature(datos_shapefile['geometry'], 
                                       ccrs.PlateCarree(), edgecolor='black', linewidth=0.3)
        ax.add_feature(shape_feature, facecolor='none')
        
    # argentina_provincias_feature = NaturalEarthFeature(
    #         category='cultural',
    #         name='admin_2_states_provinces_lines',
    #         scale='50m',
    #         facecolor='none'
    #     )
    # ax.add_feature(argentina_provincias_feature, edgecolor='black', linewidth=0.25)
        
    # plot the data
    img = ax.pcolormesh(LonCor.data, LatCor.data, CMI.data, cmap=cmap, norm=norm, transform=ccrs.PlateCarree())

    # add the colorbar
    cb = plt.colorbar(img, ticks=ticks, orientation='horizontal', extend='both',
                    cax=fig.add_axes([0.12, 0.07, 0.76, 0.02]))
    cb.ax.tick_params(labelsize=5, labelcolor='black', width=0.5, length=1.5, direction='out', pad=1.0)
    cb.outline.set_linewidth(0.5)
    #cb.set_label(label='{} [{}]'.format(CMI.standard_name, CMI.units), size=5, color='black', weight='normal')
    cb.set_label(label='{} [{}]'.format("Temperatura de superficie", CMI.units), size=5, color='black', weight='normal')    

    # set the title
    #ax.set_title('{} - C{:02d} [{:.1f} μm]'.format(sat,band, wl), fontsize=7, loc='left')
    
    # Left title
    # ax.set_title('{} - {} [{}]'.format(sat,selected_product, unit_var), fontsize=7, loc='left')
    ax.set_title('{}\n{} - {}'.format("", sat, abrev_name2), fontsize=7, loc='left')
    
    
    new_date = convertir_fecha_string(fecha_string = final_date, correccion=-3)
    # Right title
    ax.set_title('{}\n{}'.format(new_date , final_date), fontsize=7, loc='right')

    # Sets X axis characteristics
    dx = 15
    xticks = np.arange(domain[0], domain[1]+dx, dx)
    ax.set_xticks(xticks, crs=ccrs.PlateCarree())
    ax.xaxis.set_major_formatter(LongitudeFormatter(dateline_direction_label=True))
    ax.set_xlabel('Longitud', color='black', fontsize=7, labelpad=3.0)

    # Sets Y axis characteristics
    dy = 15
    yticks = np.arange(domain[2], domain[3]+dy, dy)
    ax.set_yticks(yticks, crs=ccrs.PlateCarree())
    ax.yaxis.set_major_formatter(LatitudeFormatter())
    ax.set_ylabel('Latitud', color='black', fontsize=7, labelpad=3.0)

    # Sets tick characteristics
    ax.tick_params(left=True, right=True, bottom=True, top=True,
                labelleft=True, labelright=False, labelbottom=True, labeltop=False,
                length=0.0, width=0.05, labelsize=5.0, labelcolor='black')

    # Sets grid characteristics
    ax.gridlines(xlocs=xticks, ylocs=yticks, alpha=0.6, color='gray',
                draw_labels=False, linewidth=0.25, linestyle='--')

    # set the map limits
    ax.set_extent([domain[0]+360.0, domain[1]+360.0, domain[2], domain[3]], crs=ccrs.PlateCarree())

    #output
    if plot_me:
        plt.show()

    if save_me:
        if not os.path.exists(selected_output_path) or overwrite:
            fn01.create_folder_for_file(selected_output_path)
            fig.savefig(selected_output_path, dpi=200) 
    
    # Clean...    
    plt.clf()
    
    # Close...
    plt.close()
    # Close ds    
    # ds.close()
    
    print("Close: convert_tiff2png_goes16_spi067_LSTF_v01_gen01()")
    
    return

#######################################################################################################

def convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen02_OneDay_Simple(input_folder, output_folder, gregorian_date, 
                                                                plot_me, save_me, overwrite, key_png_setup = None):

    print("Start: convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen02_OneDay_Simple()")
    
    # Import setup parameters
    # key_png_setup = "f00"
    selected_png_setup = setup_goes16_spi067_LSTF_convert_tiff2png_WGS84Proj_v01(key_png_setup)
    
    input_paths, output_paths = fn05.generator_input_and_output_paths_tiff2png_OnlyOneBand(selected_png_setup, input_folder, output_folder, gregorian_date)
   
    
    # Stock
    total_files = len(input_paths)

    # For each input file...
    for x in range(total_files):
        
        selected_input_path = input_paths[x]
        selected_output_path = output_paths[x]
        
        dt_exists = os.path.exists(selected_output_path)
        if dt_exists: 
            new_detail = "File exists!"
        elif not dt_exists:
            new_detail = "In progress..."
            
        print(f'Convertion... Init plot {x+1} of {total_files} - {new_detail}')

        if not dt_exists:
            convert_goes16_spi067_LSTF_nc2png_tiff2png_v01_gen01(selected_input_path, selected_output_path,
                                                plot_me, save_me, overwrite, key_png_setup)
        print("\n")
    print("Close: convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v02_gen02_OneDay_Simple()")
    
    return



def convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen02_OneDay_HardCoded(gregorian_date, key_png_setup = None):
    
    print('Start: convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen02_OneDay_HardCoded()')
        
    # User info - Hardcoded
    selected_png_setup = setup_goes16_spi067_LSTF_convert_tiff2png_WGS84Proj_v01(key_png_setup)
    
    input_folder = selected_png_setup["input_folder"]
    output_folder  = selected_png_setup["output_folder"] 
  
    
    plot_me = False 
    save_me = True
    overwrite = False
    
    
    # Create folder
    fn01.create_folder_if_not_exists(output_folder)
    
    # Download - gen02
    convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen02_OneDay_Simple(input_folder, output_folder, gregorian_date, plot_me, save_me, overwrite, key_png_setup)

    print('Close: convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen02_OneDay_HardCoded()')
    
    return


def convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen02_RangeDate_HardCoded(init_gregorian_date, end_gregorian_date, key_png_setup = None):
    
    print('Start: convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen02_RangeDate_HardCoded()')
    
    gregorian_list = fn02.generate_gregorian_date_list(start_date = init_gregorian_date, end_date = end_gregorian_date, key_png_setup = None)

    for x in gregorian_list:
        convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen02_OneDay_HardCoded(gregorian_date = x)
        
    print('Close: convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen02_RangeDate_HardCoded()')
     
    return



#######################################################################################################



# # # 
def convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen03_OneDay_Simple(input_folder, output_folder, gregorian_date, plot_me, save_me, overwrite, key_png_setup):

    print("Start: convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen03_OneDay_Simple()")
    
    # Import setup parameters
    # key_png_setup = "f00"
    selected_png_setup = setup_goes16_spi067_LSTF_convert_tiff2png_WGS84Proj_v01(key_png_setup)
    
    input_paths, output_paths = fn05.generator_input_and_output_paths_tiff2png_OnlyOneBand(selected_png_setup, input_folder, output_folder, gregorian_date)
    
    # Stock
    total_files = len(input_paths)

    # All arguments in tuplas
    combined_tuplas = list(zip(input_paths, output_paths,
                                [plot_me]*total_files, 
                                [save_me]*total_files, 
                                [overwrite]*total_files, 
                                [key_png_setup]*total_files))


    # Gen 03!!!
    my_function = convert_goes16_spi067_LSTF_nc2png_tiff2png_v01_gen01
    my_arguments = combined_tuplas
    # Obtener el número máximo de workers
    max_workers = os.cpu_count()

    # Cambiar el backend de Matplotlib antes de ejecutar la función en paralelo
    with Pool() as pool:
        pool.starmap(my_function, my_arguments)
        
    print("Close: convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen03_OneDay_Simple()")
    
    return



def convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen03_OneDay_HardCoded(gregorian_date = None, key_png_setup = None):
    
    print('Start: convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen03_OneDay_HardCoded()')
        
    # User info - Hardcoded
    selected_png_setup = setup_goes16_spi067_LSTF_convert_tiff2png_WGS84Proj_v01(key_png_setup)
    
    input_folder = selected_png_setup["input_folder"]
    output_folder  = selected_png_setup["output_folder"] 
    
    
    plot_me = False 
    save_me = True
    overwrite = False
    
    
    # Create folder
    fn01.create_folder_if_not_exists(output_folder)
    
    # Download - gen02
    convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen03_OneDay_Simple(input_folder, output_folder, gregorian_date, plot_me, save_me, overwrite, key_png_setup)

    print('Close: convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen03_OneDay_HardCoded()')
    
    return




def convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen03_RangeDate_HardCoded(init_gregorian_date, end_gregorian_date, key_png_setup):
    
    print('Start: convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen03_RangeDate_HardCoded()')
    
    gregorian_list = fn02.generate_gregorian_date_list(start_date = init_gregorian_date, end_date = end_gregorian_date)

    for x in gregorian_list:
        convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen03_OneDay_HardCoded(gregorian_date = x, key_png_setup = key_png_setup)
        
    print('Close: convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen03_RangeDate_HardCoded()')
     
    return

