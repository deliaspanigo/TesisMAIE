## Cargar el entorno de python
# source tesis_v004/bin/activate

## Desactivar el entorno de python
# deactivate


# Librerias
import sys
import os

# Import own libreries
fn_folder = '01.own_resources/01.python_code/01.functions/'
sys.path.append(fn_folder)

# Common resources
import fn02_time as fn02

# Especial functions
import fn067_01_goes16_spi067_LSTF_download as fn067_01
import fn067_99_goes16_spi067_LSTF_step01_ProcessOneDay as fn067_99_step01

#gregorian_date = "20230101"
#gregorian_date = fn02.get_current_date_gregorianCOMP()

def download_and_procces_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date):

    print('Start: download_and_procces_goes16_spi067_LSTF_gen02_OneDay_HardCoded()')
    
    # 01) Download
    fn067_01.download_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date)
    print("\n")
    
    # 02) Process
    fn067_99_step01.Process_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date)
    print("\n")
    
    print('Close: download_and_procces_goes16_spi067_LSTF_gen02_OneDay_HardCoded()')
    
    return