
# # # Own functions
import fn01_generic as fn01
import fn02_time as fn02
import fn05_str_paths_spected as fn05





# Libraries - v04
import os
from datetime import datetime
import cartopy.crs as ccrs
import matplotlib.pyplot as plt
import numpy as np
from cartopy.mpl.ticker import LatitudeFormatter, LongitudeFormatter
from cartopy.feature import NaturalEarthFeature

# Funciones
import rasterio
from multiprocessing import Pool


# File .nc Original projection on K
def setup_goes16_spi076_MCMIPF_convert_tiff2png_v04(selected_setup):
    principal_dic = {
        "f00": {
            "product_name": "ABI-L2-MCMIPF",
            "original_format": ".tiff",
            "new_format": ".png",
            "new_tail": "_spi076_tiff2png_v04.png",
            "prefix_file_name" : "OR_ABI-L2-MCMIPF",
            "subfolder_prod_info": "spi076_ABI-L2-MCMIPF/",
            "subfolder_version": "v04_ModProj_EPSG4326_RGB_True/",
            "abrev_name": "MCMIPF",
            "domain": [-165.0,15.0,-90.0,90.0]
            
        },
        "f01": {
            "key": "02",
            "folder": "coolwarm/",
            "cmap": "coolwarm",
            "new_tail": "_tiff2png02.png",
            "prefix_file_name" : "OR_ABI-L2-LSTF",
            "subfolder_name": "ABI-L2-LSTF",
            "original_format": ".nc"
        },
    }

    return principal_dic[selected_setup]

def convert_tiff2png_goes16_spi076_MCMIPF_v04_gen01(selected_input_path, selected_output_path, plot_me = True, save_me = True, overwrite = False):
    
    if plot_me or save_me:
        dt_ok = True
        
    if not dt_ok:
        print("Arguments plot_me and save_me are 'False'.") 
        return
    
    # Scan's start time, converted to datetime object


    ## Abrir el archivo con rasterio
    with rasterio.open(selected_input_path) as src:
        # Leer las tres bandas
        r, g, b = src.read()

        # Obtener la información de transformación
        transform = src.transform
        profile = src.profile
        xmin, ymin, xmax, ymax = src.bounds


    # Crear una imagen RGB combinando las tres bandas
    rgb_image = (r, g, b)
    rgb_image = np.transpose([r, g, b], (1, 2, 0))
    
    domain_map =  [-180, 180, -90, 90]
    domain_img = [xmin,  xmax, ymin, ymax]
    
    # Central longitud for domains
    lon_cen_map = 360.0+(domain_map[0]+domain_map[1])/2.0
    lon_cen_img = 360.0+(domain_img[0]+domain_img[1])/2.0
     
    # creates the figure
    fig = plt.figure('map', figsize=(4,4), dpi=200)
    ax = fig.add_axes([0.1, 0.16, 0.80, 0.75], projection=ccrs.PlateCarree(lon_cen_map))
    
     # set the map limits
    ax.set_extent([domain_map[0]+360.0, domain_map[1]+360.0, domain_map[2], domain_map[3]], crs=ccrs.PlateCarree())


    #img = ax.pcolormesh(LonCor.data, LatCor.data, CMI.data, cmap=cmap, norm=norm, transform=ccrs.PlateCarree())

    ax.imshow(rgb_image, extent = domain_img, origin='upper', transform=ccrs.PlateCarree())
    # add the geographic boundaries
    l = NaturalEarthFeature(category='cultural', name='admin_0_countries', scale='50m', facecolor='none')
    #ax.add_feature(l, edgecolor='gold', linewidth=0.25)
    ax.add_feature(l, edgecolor='black', linewidth=0.25)
    
        # Sets X axis characteristics
    dx = 15
    xticks = np.arange(domain_map[0], domain_map[1]+dx, dx)
    ax.set_xticks(xticks, crs=ccrs.PlateCarree())
    ax.xaxis.set_major_formatter(LongitudeFormatter(dateline_direction_label=True))
    ax.set_xlabel('Longitude', color='black', fontsize=7, labelpad=3.0)
    
        # Sets Y axis characteristics
    dy = 15
    yticks = np.arange(domain_map[2], domain_map[3]+dy, dy)
    ax.set_yticks(yticks, crs=ccrs.PlateCarree())
    ax.yaxis.set_major_formatter(LatitudeFormatter())
    ax.set_ylabel('Latitude', color='black', fontsize=7, labelpad=3.0)
    
        # Sets tick characteristics
    ax.tick_params(left=True, right=True, bottom=True, top=True,
                labelleft=True, labelright=False, labelbottom=True, labeltop=False,
                length=0.0, width=0.05, labelsize=5.0, labelcolor='black')
    
    # Sets grid characteristics
    ax.gridlines(xlocs=xticks, ylocs=yticks, alpha=0.6, color='gray',
                draw_labels=False, linewidth=0.25, linestyle='--')

    # ax.coastlines(resolution='10m', color='gold', linewidth=1)
    
    
   

    # plt.title('GOES-16 True Color', fontweight='bold', fontsize=15, loc='left')
    #plt.title('Full Disk\n{}'.format(scan_start.strftime('%H:%M UTC %d %B %Y')),
    #        loc='right')
    
    # Configurar etiquetas y título
    # ax.set_xlabel('Longitud')
    # ax.set_ylabel('Latitud')
    # ax.set_title('Imagen RGB')

    #output
    if plot_me:
        plt.show()

    if save_me:
        if not os.path.exists(selected_output_path) or overwrite:
            fn01.create_folder_for_file(selected_output_path)
            fig.savefig(selected_output_path, dpi=200) 
    
    # Clean...    
    plt.clf()
    
    # Close...
    plt.close()
    # Close ds    
    # ds.close()
    
    return


###################################################################################################


def convert_tiff2png_goes16_spi076_MCMIPF_v04_gen02_OneDay_Simple(input_folder, output_folder, gregorian_date, plot_me, save_me, overwrite):

    print("Start: convert_tiff2png_goes16_spi076_MCMIPF_v04_gen02_OneDay_Simple()")
    
    key_png_setup = "f00"
    selected_png_setup = setup_goes16_spi076_MCMIPF_convert_tiff2png_v04(key_png_setup)
    
    
    input_paths, output_paths = fn05.generator_input_and_output_paths_tiff2png_OnlyOneBand(selected_png_setup, input_folder, output_folder, gregorian_date)
   
  
    # Stock
    total_files = len(input_paths)

    for x in range(total_files):
        
        selected_input_path = input_paths[x]
        selected_output_path = output_paths[x]
        
        dt_exists = os.path.exists(selected_output_path)
        if dt_exists: 
            new_detail = "File exists!"
        elif not dt_exists:
            new_detail = "In progress..."
            
        print(f'Convertion... Init plot {x+1} of {total_files} - {new_detail}')

        if not dt_exists:
            convert_tiff2png_goes16_spi076_MCMIPF_v04_gen01(selected_input_path, selected_output_path,
                                                plot_me, save_me, overwrite)
        
    print("Close: convert_tiff2png_goes16_spi076_MCMIPF_v04_gen02_OneDay_Simple()")
    
    return




def convert_tiff2png_goes16_spi076_MCMIPF_v04_gen02_OneDay_HardCoded(gregorian_date = None):
    
    print('Start: convert_tiff2png_goes16_spi076_MCMIPF_v04_gen02_OneDay_HardCoded()')
        
    # User info - Hardcoded
    input_folder = '02.total_view/04.nc2tiff/'
    output_folder  = '02.total_view/05.tiff2png/' 
    plot_me = False 
    save_me = True
    overwrite = False
    
    
    # Create folder
    fn01.create_folder_if_not_exists(output_folder)
    
    # Download - gen02
    convert_tiff2png_goes16_spi076_MCMIPF_v04_gen02_OneDay_Simple(input_folder, output_folder, gregorian_date, plot_me, save_me, overwrite)

    print('Close: convert_tiff2png_goes16_spi076_MCMIPF_v04_gen02_OneDay_HardCoded()')
    
    return



def convert_tiff2png_goes16_spi076_MCMIPF_v04_gen02_RangeDate_HardCoded(init_gregorian_date, end_gregorian_date):
    
    print('Start: convert_tiff2png_goes16_spi076_MCMIPF_v04_gen02_RangeDate_HardCoded()')
    
    gregorian_list = fn02.generate_gregorian_date_list(start_date = init_gregorian_date, end_date = end_gregorian_date)

    for x in gregorian_list:
        convert_tiff2png_goes16_spi076_MCMIPF_v04_gen02_OneDay_HardCoded(gregorian_date = x)
        
    print('Close: convert_tiff2png_goes16_spi076_MCMIPF_v04_gen02_RangeDate_HardCoded()')
     
    return

######################################################################################################






def convert_tiff2png_goes16_spi076_MCMIPF_v04_gen03_OneDay_Simple(input_folder, output_folder, gregorian_date, plot_me, save_me, overwrite):

    print("Start: convert_tiff2png_goes16_spi076_MCMIPF_v04_gen03_OneDay_Simple()")
    
    # Import setup parameters
    key_png_setup = "f00"
    selected_png_setup = setup_goes16_spi076_MCMIPF_convert_tiff2png_v04(key_png_setup)
    
    input_paths, output_paths = fn05.generator_input_and_output_paths_tiff2png_OnlyOneBand(selected_png_setup, input_folder, output_folder, gregorian_date)
   
 
 
    # Stock
    total_files = len(input_paths)

    # All arguments in tuplas
    combined_tuplas = list(zip(input_paths, output_paths,
                                [plot_me]*total_files, [save_me]*total_files, [overwrite]*total_files))


    # Gen 03!!!
    my_function = convert_tiff2png_goes16_spi076_MCMIPF_v04_gen01
    my_arguments = combined_tuplas
    # Obtener el número máximo de workers
    max_workers = os.cpu_count()

    # Cambiar el backend de Matplotlib antes de ejecutar la función en paralelo
    with Pool() as pool:
        pool.starmap(my_function, my_arguments)
        
    print("Close: convert_tiff2png_goes16_spi076_MCMIPF_v04_gen03_OneDay_Simple()")
    
    return



def convert_tiff2png_goes16_spi076_MCMIPF_v04_gen03_OneDay_HardCoded(gregorian_date = None):
    
    print('Start: convert_tiff2png_goes16_spi076_MCMIPF_v04_gen03_OneDay_HardCoded()')
        
    # User info - Hardcoded
    input_folder = '02.total_view/04.nc2tiff/'
    output_folder  = '02.total_view/05.tiff2png/' 
    plot_me = False 
    save_me = True
    overwrite = False
    
    
    # Create folder
    fn01.create_folder_if_not_exists(output_folder)
    
    # Download - gen02
    convert_tiff2png_goes16_spi076_MCMIPF_v04_gen03_OneDay_Simple(input_folder, output_folder, gregorian_date, plot_me, save_me, overwrite)

    print('Close: convert_tiff2png_goes16_spi076_MCMIPF_v04_gen03_OneDay_HardCoded()')
    
    return




def convert_tiff2png_goes16_spi076_MCMIPF_v04_gen03_RangeDate_HardCoded(init_gregorian_date, end_gregorian_date):
    
    print('Start: convert_tiff2png_goes16_spi076_MCMIPF_v04_gen03_RangeDate_HardCoded()')
    
    gregorian_list = fn02.generate_gregorian_date_list(start_date = init_gregorian_date, end_date = end_gregorian_date)

    for x in gregorian_list:
        convert_tiff2png_goes16_spi076_MCMIPF_v04_gen03_OneDay_HardCoded(gregorian_date = x)
        
    print('Close: convert_tiff2png_goes16_spi076_MCMIPF_v04_gen03_RangeDate_HardCoded()')
     
    return



