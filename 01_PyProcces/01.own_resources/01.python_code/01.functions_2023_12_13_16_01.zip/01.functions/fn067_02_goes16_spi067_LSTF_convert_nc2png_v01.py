
# # # Own functions
import fn01_generic as fn01
import fn02_time as fn02
import fn05_str_paths_spected as fn05

import re

# Libraries - v01 
import GOES
import custom_color_palette as ccp
import matplotlib.pyplot as plt
import numpy as np
import cartopy.crs as ccrs
from cartopy.feature import NaturalEarthFeature


# Libraries - v02
import os
import rioxarray as rxr
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.image import imread
from itertools import compress
from cartopy.mpl.ticker import LatitudeFormatter, LongitudeFormatter
import re
# Funciones
from joblib import Parallel, delayed

from multiprocessing import Pool
import time
import math


# File .nc Original projection on K
def setup_goes16_spi067_LSTF_convert_nc2png_v01(selected_setup):
    principal_dic = {
        "f00": {
            "product_name": "ABI-L2-LSTF",
            "original_format": ".nc",
            "new_format": ".png",
            "new_tail": "_spi067_nc2png_v01.png",
            "prefix_file_name" : "OR_ABI-L2-LSTF",
            "subfolder_prod_info": "spi067_ABI-L2-LSTF/",
            "subfolder_version": "v01_OrigProj_Kelvin/",
            "abrev_name": "LST",
            "domain": [-165.0,15.0,-90.0,90.0],
            "unit_var": "K",
            "min_var": 210.0,
            "max_var": 340.0,
            "mini_step": 1.0,
            "big_step": 10
            
        },
        "f01": {
            "key": "02",
            "folder": "coolwarm/",
            "cmap": "coolwarm",
            "new_tail": "_nc2png02.png",
            "prefix_file_name" : "OR_ABI-L2-LSTF",
            "subfolder_name": "ABI-L2-LSTF",
            "original_format": ".nc"
        },
    }

    return principal_dic[selected_setup]


def convert_nc2png_goes16_spi067_LSTF_v01_gen01(selected_input_path, selected_output_path, plot_me = True, save_me = True, overwrite = False):
    
    print("Start: convert_nc2png_goes16_spi067_LSTF_v01_gen01()")
    
   
        
    if plot_me or save_me:
        dt_ok = True
        
    if not dt_ok:
        print("Arguments plot_me and save_me are 'False'.") 
        return
    
    # Setup png
    key_png_setup = "f00"
    selected_png_setup = setup_goes16_spi067_LSTF_convert_nc2png_v01(key_png_setup)
    
    selected_product = selected_png_setup["product_name"]
    abrev_name = selected_png_setup["abrev_name"]
    domain = selected_png_setup["domain"]
    unit_var = selected_png_setup["unit_var"]
    min_var = selected_png_setup["min_var"]
    max_var = selected_png_setup["max_var"]
    mini_step = selected_png_setup["mini_step"]
    big_step = selected_png_setup["big_step"]
    
    
    # Import .nc file and setup for more details
    ds = GOES.open_dataset(selected_input_path)
    CMI, LonCor, LatCor = ds.image(abrev_name, lonlat='corner')
    sat = ds.attribute('platform_ID')
    sat_info = ds.variable('goes_imager_projection')
    lon_sat = sat_info.longitude_of_projection_origin
    hsat = sat_info.perspective_point_height
    
    
    # # # Setings colours
    # set the colors of the custom palette
    lower_colors = ['maroon','red','darkorange','#ffff00','forestgreen','cyan','royalblue',(148/255,0/255,211/255)]
    lower_colors.reverse()

    lower_palette = [lower_colors, ccp.range(min_var,max_var,mini_step)]


    # pass parameters to the creates_palette module
    # cmap, cmticks, norm, bounds = ccp.creates_palette([lower_palette, upper_palette], extend='both')
    cmap, cmticks, norm, bounds = ccp.creates_palette([lower_palette], extend='both')

    # creating colorbar labels
    ticks = ccp.range(min_var,max_var,big_step)


    # # # Plot
    plt.switch_backend('Agg') # Esto es para que en ejecucion en paralelo no haya problemas.
    
    fig = plt.figure('Geo', figsize=(4,4), dpi=200)
    ax = fig.add_axes([0.1, 0.16, 0.80, 0.75],
                    projection=ccrs.Geostationary(central_longitude=lon_sat, satellite_height=hsat))
    #ax.outline_patch.set_linewidth(0.3)

    # add the geographic boundaries
    l = NaturalEarthFeature(category='cultural', name='admin_0_countries', scale='50m', facecolor='none')
    # ax.add_feature(l, edgecolor='gold', linewidth=0.25)
    ax.add_feature(l, edgecolor='black', linewidth=0.25)

    # plot the data
    img = ax.pcolormesh(LonCor.data, LatCor.data, CMI.data, cmap=cmap, norm=norm, transform=ccrs.PlateCarree())

    # add the colorbar
    cb = plt.colorbar(img, ticks=ticks, orientation='horizontal', extend='both',
                    cax=fig.add_axes([0.12, 0.1, 0.76, 0.02]))
    cb.ax.tick_params(labelsize=5, labelcolor='black', width=0.5, length=1.5, direction='out', pad=1.0)
    cb.set_label(label='{} [{}]'.format(CMI.standard_name, CMI.units), size=5, color='black', weight='normal')
    cb.outline.set_linewidth(0.5)

    # set the title
    # ax.set_title('{} - C{:02d} [{:.1f} μm]'.format(sat,band, wl), fontsize=7, loc='left')
    ax.set_title('{} - {} [{}]'.format(sat,selected_product, unit_var), fontsize=7, loc='left')
    ax.set_title(CMI.time_bounds.data[0].strftime('%Y/%m/%d %H:%M UTC'), fontsize=7, loc='right')
    
    
    # Sets X axis characteristics
    dx = 15
    xticks = np.arange(domain[0], domain[1]+dx, dx)

    # Sets Y axis characteristics
    dy = 15
    yticks = np.arange(domain[2], domain[3]+dy, dy)

    # Sets tick characteristics
    ax.tick_params(left=True, right=True, bottom=True, top=True,
                labelleft=True, labelright=False, labelbottom=True, labeltop=False,
                length=0.0, width=0.05, labelsize=5.0, labelcolor='black')

    # Sets grid characteristics
    ax.gridlines(xlocs=xticks, ylocs=yticks, alpha=0.6, color='gray',
                draw_labels=False, linewidth=0.25, linestyle='--')

    #output
    if plot_me:
        plt.show()

    if save_me:
        if not os.path.exists(selected_output_path) or overwrite:
            fn01.create_folder_for_file(selected_output_path)
            fig.savefig(selected_output_path, dpi=200) 
    
    # Clean...    
    plt.clf()
    
    # Close...
    plt.close()
    # Close ds    
    # ds.close()
    
    print("Close: convert_nc2png_goes16_spi067_LSTF_v01_gen01()")
    
    return

#######################################################################################################

def convert_nc2png_goes16_spi067_LSTF_v01_gen02_OneDay_Simple(input_folder, output_folder, gregorian_date, plot_me, save_me, overwrite):

    print("Start: convert_nc2png_goes16_spi067_LSTF_v01_gen02_OneDay_Simple()")
    
    # Import setup parameters
    key_png_setup = "f00"
    selected_png_setup = setup_goes16_spi067_LSTF_convert_nc2png_v01(key_png_setup)
    
    input_paths, output_paths = fn05.generator_input_and_output_paths_nc2png_OnlyOneBand(selected_png_setup, input_folder, output_folder, gregorian_date)
   
 
    # Stock
    total_files = len(input_paths)

    # For each input file...
    for x in range(total_files):
        
        selected_input_path = input_paths[x]
        selected_output_path = output_paths[x]
        
        dt_exists = os.path.exists(selected_output_path)
        if dt_exists: 
            new_detail = "File exists!"
        elif not dt_exists:
            new_detail = "In progress..."
            
        print(f'Convertion... Init plot {x+1} of {total_files} - {new_detail}')

        if not dt_exists:
            convert_nc2png_goes16_spi067_LSTF_v01_gen01(selected_input_path, selected_output_path,
                                                plot_me, save_me, overwrite)
        
    print("Close: convert_nc2png_goes16_spi067_LSTF_v01_gen02_OneDay_Simple()")
    
    return



def convert_nc2png_goes16_spi067_LSTF_v01_gen02_OneDay_HardCoded(gregorian_date = None):
    
    print('Start: convert_nc2png_goes16_spi067_LSTF_v01_gen02_OneDay_HardCoded()')
        
    # User info - Hardcoded
    input_folder = '02.total_view/01.goes16_files_nc/'
    output_folder  = '02.total_view/02.nc2png/' 
    plot_me = False 
    save_me = True
    overwrite = False
    
    
    # Create folder
    fn01.create_folder_if_not_exists(output_folder)
    
    # Download - gen02
    convert_nc2png_goes16_spi067_LSTF_v01_gen02_OneDay_Simple(input_folder, output_folder, gregorian_date, plot_me, save_me, overwrite)

    print('Close: convert_nc2png_goes16_spi067_LSTF_v01_gen02_OneDay_HardCoded()')
    
    return


def convert_nc2png_goes16_spi067_LSTF_v01_gen02_RangeDate_HardCoded(init_gregorian_date, end_gregorian_date):
    
    print('Start: convert_nc2png_goes16_spi067_LSTF_v01_gen02_RangeDate_HardCoded()')
    
    gregorian_list = fn02.generate_gregorian_date_list(start_date = init_gregorian_date, end_date = end_gregorian_date)

    for x in gregorian_list:
        convert_nc2png_goes16_spi067_LSTF_v01_gen02_OneDay_HardCoded(gregorian_date = x)
        
    print('Close: convert_nc2png_goes16_spi067_LSTF_v01_gen02_RangeDate_HardCoded()')
     
    return



#######################################################################################################




def convert_nc2png_goes16_spi067_LSTF_v01_gen03_OneDay_Simple(input_folder, output_folder, gregorian_date, plot_me, save_me, overwrite):

    print("Start: convert_nc2png_goes16_spi067_LSTF_v01_gen03_OneDay_Simple()")
    
    # Import setup parameters
    key_png_setup = "f00"
    selected_png_setup = setup_goes16_spi067_LSTF_convert_nc2png_v01(key_png_setup)
    
    input_paths, output_paths = fn05.generator_input_and_output_paths_nc2png_OnlyOneBand(selected_png_setup, input_folder, output_folder, gregorian_date)
    
    # Stock
    total_files = len(input_paths)

    # All arguments in tuplas
    combined_tuplas = list(zip(input_paths, output_paths,
                                [plot_me]*total_files, [save_me]*total_files, [overwrite]*total_files))


    # Gen 03!!!
    my_function = convert_nc2png_goes16_spi067_LSTF_v01_gen01
    my_arguments = combined_tuplas
    # Obtener el número máximo de workers
    max_workers = os.cpu_count()

    # Cambiar el backend de Matplotlib antes de ejecutar la función en paralelo
    with Pool() as pool:
        pool.starmap(my_function, my_arguments)
        
    print("Close: convert_nc2png_goes16_spi067_LSTF_v01_gen03_OneDay_Simple()")
    
    return



def convert_nc2png_goes16_spi067_LSTF_v01_gen03_OneDay_HardCoded(gregorian_date = None):
    
    print('Start: convert_nc2png_goes16_spi067_LSTF_v01_gen03_OneDay_HardCoded()')
        
    # User info - Hardcoded
    input_folder = '02.total_view/01.goes16_files_nc/'
    output_folder  = '02.total_view/02.nc2png/' 
    plot_me = False 
    save_me = True
    overwrite = False
    
    
    # Create folder
    fn01.create_folder_if_not_exists(output_folder)
    
    # Download - gen02
    convert_nc2png_goes16_spi067_LSTF_v01_gen03_OneDay_Simple(input_folder, output_folder, gregorian_date, plot_me, save_me, overwrite)

    print('Close: convert_nc2png_goes16_spi067_LSTF_v01_gen03_OneDay_HardCoded()')
    
    return




def convert_nc2png_goes16_spi067_LSTF_v01_gen03_RangeDate_HardCoded(init_gregorian_date, end_gregorian_date):
    
    print('Start: convert_nc2png_goes16_spi067_LSTF_v01_gen03_RangeDate_HardCoded()')
    
    gregorian_list = fn02.generate_gregorian_date_list(start_date = init_gregorian_date, end_date = end_gregorian_date)

    for x in gregorian_list:
        convert_nc2png_goes16_spi067_LSTF_v01_gen03_OneDay_HardCoded(gregorian_date = x)
        
    print('Close: convert_nc2png_goes16_spi067_LSTF_v01_gen03_RangeDate_HardCoded()')
     
    return

