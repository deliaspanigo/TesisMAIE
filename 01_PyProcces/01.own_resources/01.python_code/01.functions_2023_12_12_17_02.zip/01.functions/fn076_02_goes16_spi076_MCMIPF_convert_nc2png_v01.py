
# # # Own functions
import fn01_generic as fn01
import fn02_time as fn02
import fn05_str_paths_spected as fn05





# Libraries - v02
import os
from datetime import datetime
import cartopy.crs as ccrs
import matplotlib.pyplot as plt
import numpy as np
import xarray

# Funciones
from multiprocessing import Pool


# File .nc Original projection on K
def setup_goes16_spi076_MCMIPF_convert_nc2png_v01(selected_setup):
    principal_dic = {
        "f00": {
            "product_name": "ABI-L2-MCMIPF",
            "original_format": ".nc",
            "new_format": ".png",
            "new_tail": "_spi076_nc2png_v01.png",
            "prefix_file_name" : "OR_ABI-L2-MCMIPF",
            "subfolder_prod_info": "spi076_ABI-L2-MCMIPF/",
            "subfolder_version": "v01_OrigProj_RGB_True/",
            "abrev_name": "MCMIPF",
            "domain": [-165.0,15.0,-90.0,90.0]
            
        },
        "f01": {
            "key": "02",
            "folder": "coolwarm/",
            "cmap": "coolwarm",
            "new_tail": "_nc2png02.png",
            "prefix_file_name" : "OR_ABI-L2-LSTF",
            "subfolder_name": "ABI-L2-LSTF",
            "original_format": ".nc"
        },
    }

    return principal_dic[selected_setup]


def convert_nc2png_goes16_spi076_MCMIPF_v01_gen01(selected_input_path, selected_output_path, plot_me = True, save_me = True, overwrite = False):
    
    if plot_me or save_me:
        dt_ok = True
        
    if not dt_ok:
        print("Arguments plot_me and save_me are 'False'.") 
        return
    
# Lectura de variables específicas
    with xarray.open_dataset(selected_input_path) as F:
        # Resto del código...

        # Scan's start time, converted to datetime object
        scan_start = datetime.strptime(F.time_coverage_start, '%Y-%m-%dT%H:%M:%S.%fZ')

        # Scan's end time, converted to datetime object
        scan_end = datetime.strptime(F.time_coverage_end, '%Y-%m-%dT%H:%M:%S.%fZ')

        # File creation time, convert to datetime object
        file_created = datetime.strptime(F.date_created, '%Y-%m-%dT%H:%M:%S.%fZ')

        # The 't' variable is the scan's midpoint time
        midpoint = str(F['t'].data)[:-8]
        
        scan_mid = datetime.strptime(midpoint, '%Y-%m-%dT%H:%M:%S.%f')
        
        
        # We'll use the `CMI_C02` variable as a 'hook' to get the CF metadata.
        dat = F.metpy.parse_cf('CMI_C02')
        geos = dat.metpy.cartopy_crs
        x = dat.x
        y = dat.y
    
        # Load the RGB arrays
        R = np.clip(F['CMI_C02'][:].data, 0, 1)
        G = np.clip(F['CMI_C03'][:].data, 0, 1)
        B = np.clip(F['CMI_C01'][:].data, 0, 1)

   


    # Apply the gamma correction
    gamma = 2.2
    R = np.power(R, 1/gamma)
    G = np.power(G, 1/gamma)
    B = np.power(B, 1/gamma)

    # Calculate the "True" Green
    G_true = 0.48358168 * R + 0.45706946 * B + 0.06038137 * G
    G_true = np.clip(G_true, 0, 1)

    # The final RGB array :)
    RGB = np.dstack([R, G_true, B])


    plt.switch_backend('Agg') # Esto es para que en ejecucion en paralelo no haya problemas.
    fig = plt.figure(figsize=(10, 8))

    ax = fig.add_subplot(1, 1, 1, projection=geos)

    ax.imshow(RGB, origin='upper',
            extent=(x.min(), x.max(), y.min(), y.max()),
            transform=geos)

    # ax.coastlines(resolution='50m', color='gold', linewidth=1)
    # ax.add_feature(ccrs.cartopy.feature.BORDERS, linewidth=1)

    plt.title('GOES-16 True Color', fontweight='bold', fontsize=15, loc='left')
    plt.title('Full Disk\n{}'.format(scan_start.strftime('%H:%M UTC %d %B %Y')),
            loc='right')

    #output
    if plot_me:
        plt.show()

    if save_me:
        if not os.path.exists(selected_output_path) or overwrite:
            fn01.create_folder_for_file(selected_output_path)
            fig.savefig(selected_output_path, dpi=200) 
    
    # Clean...    
    plt.clf()
    
    # Close...
    plt.close()
    # Close ds    
    # ds.close()
    
    return


###################################################################################################


def convert_nc2png_goes16_spi076_MCMIPF_v01_gen02_OneDay_Simple(input_folder, output_folder, gregorian_date, plot_me, save_me, overwrite):

    print("Start: convert_nc2png_goes16_spi076_MCMIPF_v01_gen02_OneDay_Simple()")
    
    key_png_setup = "f00"
    selected_png_setup = setup_goes16_spi076_MCMIPF_convert_nc2png_v01(key_png_setup)
    
    
    input_paths, output_paths = fn05.generator_input_and_output_paths_nc2png_OnlyOneBand(selected_png_setup, input_folder, output_folder, gregorian_date)
   
  
    # Stock
    total_files = len(input_paths)

    for x in range(total_files):
        
        selected_input_path = input_paths[x]
        selected_output_path = output_paths[x]
        
        dt_exists = os.path.exists(selected_output_path)
        if dt_exists: 
            new_detail = "File exists!"
        elif not dt_exists:
            new_detail = "In progress..."
            
        print(f'Convertion... Init plot {x+1} of {total_files} - {new_detail}')

        if not dt_exists:
            convert_nc2png_goes16_spi076_MCMIPF_v01_gen01(selected_input_path, selected_output_path,
                                                plot_me, save_me, overwrite)
        
    print("Close: convert_nc2png_goes16_spi076_MCMIPF_v01_gen02_OneDay_Simple()")
    
    return




def convert_nc2png_goes16_spi076_MCMIPF_v01_gen02_OneDay_HardCoded(gregorian_date = None):
    
    print('Start: convert_nc2png_goes16_spi076_MCMIPF_v01_gen02_OneDay_HardCoded()')
        
    # User info - Hardcoded
    input_folder = '02.total_view/01.goes16_files_nc/'
    output_folder  = '02.total_view/02.nc2png/' 
    plot_me = False 
    save_me = True
    overwrite = False
    
    
    # Create folder
    fn01.create_folder_if_not_exists(output_folder)
    
    # Download - gen02
    convert_nc2png_goes16_spi076_MCMIPF_v01_gen02_OneDay_Simple(input_folder, output_folder, gregorian_date, plot_me, save_me, overwrite)

    print('Close: convert_nc2png_goes16_spi076_MCMIPF_v01_gen02_OneDay_HardCoded()')
    
    return



def convert_nc2png_goes16_spi076_MCMIPF_v01_gen02_RangeDate_HardCoded(init_gregorian_date, end_gregorian_date):
    
    print('Start: convert_nc2png_goes16_spi076_MCMIPF_v01_gen02_RangeDate_HardCoded()')
    
    gregorian_list = fn02.generate_gregorian_date_list(start_date = init_gregorian_date, end_date = end_gregorian_date)

    for x in gregorian_list:
        convert_nc2png_goes16_spi076_MCMIPF_v01_gen02_OneDay_HardCoded(gregorian_date = x)
        
    print('Close: convert_nc2png_goes16_spi076_MCMIPF_v01_gen02_RangeDate_HardCoded()')
     
    return

######################################################################################################






def convert_nc2png_goes16_spi076_MCMIPF_v01_gen03_OneDay_Simple(input_folder, output_folder, gregorian_date, plot_me, save_me, overwrite):

    print("Start: convert_nc2png_goes16_spi076_MCMIPF_v01_gen03_OneDay_Simple()")
    
    # Import setup parameters
    key_png_setup = "f00"
    selected_png_setup = setup_goes16_spi076_MCMIPF_convert_nc2png_v01(key_png_setup)
    
    input_paths, output_paths = fn05.generator_input_and_output_paths_nc2png_OnlyOneBand(selected_png_setup, input_folder, output_folder, gregorian_date)
   
 
 
    # Stock
    total_files = len(input_paths)

    # All arguments in tuplas
    combined_tuplas = list(zip(input_paths, output_paths,
                                [plot_me]*total_files, [save_me]*total_files, [overwrite]*total_files))


    # Gen 03!!!
    my_function = convert_nc2png_goes16_spi076_MCMIPF_v01_gen01
    my_arguments = combined_tuplas
    # Obtener el número máximo de workers
    max_workers = os.cpu_count()

    # Cambiar el backend de Matplotlib antes de ejecutar la función en paralelo
    with Pool() as pool:
        pool.starmap(my_function, my_arguments)
        
    print("Close: convert_nc2png_goes16_spi076_MCMIPF_v01_gen03_OneDay_Simple()")
    
    return



def convert_nc2png_goes16_spi076_MCMIPF_v01_gen03_OneDay_HardCoded(gregorian_date = None):
    
    print('Start: convert_nc2png_goes16_spi076_MCMIPF_v01_gen03_OneDay_HardCoded()')
        
    # User info - Hardcoded
    input_folder = '02.total_view/01.goes16_files_nc/'
    output_folder  = '02.total_view/02.nc2png/' 
    plot_me = False 
    save_me = True
    overwrite = False
    
    
    # Create folder
    fn01.create_folder_if_not_exists(output_folder)
    
    # Download - gen02
    convert_nc2png_goes16_spi076_MCMIPF_v01_gen03_OneDay_Simple(input_folder, output_folder, gregorian_date, plot_me, save_me, overwrite)

    print('Close: convert_nc2png_goes16_spi076_MCMIPF_v01_gen03_OneDay_HardCoded()')
    
    return




def convert_nc2png_goes16_spi076_MCMIPF_v01_gen03_RangeDate_HardCoded(init_gregorian_date, end_gregorian_date):
    
    print('Start: convert_nc2png_goes16_spi076_MCMIPF_v01_gen03_RangeDate_HardCoded()')
    
    gregorian_list = fn02.generate_gregorian_date_list(start_date = init_gregorian_date, end_date = end_gregorian_date)

    for x in gregorian_list:
        convert_nc2png_goes16_spi076_MCMIPF_v01_gen03_OneDay_HardCoded(gregorian_date = x)
        
    print('Close: convert_nc2png_goes16_spi076_MCMIPF_v01_gen03_RangeDate_HardCoded()')
     
    return



