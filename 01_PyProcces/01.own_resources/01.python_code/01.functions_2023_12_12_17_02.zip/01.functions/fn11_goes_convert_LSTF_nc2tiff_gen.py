# # # Own functions
import fn01_generic as fn01
import fn02_time as fn02
import fn05_str_paths_spected as fn05

# Convertion n2 to tiff only for LSTF product.


# Librerias
import rioxarray as rxr
from itertools import compress
import os



def tiff_setup_LSTF_nc2tiff(selected_setup):
    principal_dic = {
        "tiff01": {
            "key": "01",
        #    "cmap": "Reds",
            "new_tail": ".tiff",
            "prefix_file_name" : "OR_ABI-L2-LSTF",
            "subfolder_name": "ABI-L2-LSTF",
            "original_format": ".nc"
        }
    }

    return principal_dic[selected_setup]



# .nc to tiff
def convert_LSTF_nc2tiff_gen01(input_path, output_path):

    # Se establece el la referencia espacial y se define en el archivo
    selected_epsg = "EPSG:4326"
    spatial_ref = 'PROJCS["unnamed",GEOGCS["unknown",DATUM["unnamed",SPHEROID["Spheroid",6378137,298.2572221]],PRIMEM["Greenwich",0],UNIT["degree",0.0174532925199433,AUTHORITY["EPSG","9122"]]],PROJECTION["Geostationary_Satellite"],PARAMETER["central_meridian",-75],PARAMETER["satellite_height",35786023],PARAMETER["false_easting",0],PARAMETER["false_northing",0],UNIT["metre",1,AUTHORITY["EPSG","9001"]],AXIS["Easting",EAST],AXIS["Northing",NORTH],EXTENSION["PROJ4","+proj=geos +lon_0=-75 +h=35786023 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs +sweep=x"]]'

 
    
    # Open .nc file
    new_tiff = rxr.open_rasterio(input_path, mask_and_scale=True)

    # Atributtes changes
    # nc_mod.attrs["units"] =  "C"   No me cambia las unidades.
    
    # General changes
    new_tiff = new_tiff.rio.set_crs(spatial_ref)         # CRS
    new_tiff = new_tiff.rio.reproject(selected_epsg) # EPSG
    new_tiff = new_tiff.astype(float)  # Float 64 para todas las bandas
    new_tiff = new_tiff.rio.write_crs(selected_epsg, inplace=True)  # 
    
 
    
    # Selected band changes
    new_tiff['LST'][0] = new_tiff['LST'][0] - 273.15   # Pasamos de Kelvin a Celcius
    new_tiff['LST'][0] = new_tiff['LST'][0].fillna(-9999)

    # # Clip por bbox
    # nc_mod = nc_mod.rio.clip_box(
    #     minx=-68,
    #     miny=-42,
    #     maxx=-55,
    #     maxy=-21,
    #     crs=selected_epsg,
    # )
    
    fn01.create_folder_for_file(output_path)
    new_tiff.LST.rio.to_raster(output_path)


    
    
    # nc_mod
    # nc_original.close()
    new_tiff.close()
    
   
    return




def convert_LSTF_nc2tiff_gen02(input_folder, output_folder, new_tail = "", tell_me = False):

    if tell_me:
        print(f'-convert_LSTF_nc2tiff_gen02()"')

    # # # Process
    # 1) Create output folder
    fn01.create_folder_if_not_exists(output_folder)


    # Input and output paths for each file
    input_paths = fn01.list_paths_in_folder(input_folder)
    input_paths = [element for element in input_paths if element.endswith(".nc")]

    output_paths = fn05.list_spected_output_paths_nc2tiff(input_paths, input_folder, output_folder, new_tail)
    
    # Convertion for only one files
    for x in range(len(input_paths)):
        selected_input_path = input_paths[x]
        selected_output_path = output_paths[x]
        
        # # # ACA PUEDO AGREGAR CONTROLES
        dt_output_file = os.path.exists(selected_output_path)
            
        if not dt_output_file:    
            convert_LSTF_nc2tiff_gen01(input_path = selected_input_path,
                                      output_path = selected_output_path)
            if tell_me:
                print("Convertion nc2tiff...")
            
        elif dt_output_file:
            if tell_me:
                print("File exists!")
            
    return        




def convert_LSTF_nc2tiff_gen03_OneDay(general_input_folder, general_output_folder, selected_gregorian_date_SEP, tell_me = True):
        
    if tell_me:
        print(f'-convert_LSTF_nc2tiff_gen03()"')
            
    all_key = ["tiff01"]
    
    for x in range(len(all_key)):
        ################################################################
        key_png_setup = all_key[x]
        selected_png_setup = tiff_setup_LSTF_nc2tiff(key_png_setup)
        ###############################################################

        sat_prod =     selected_png_setup["subfolder_name"]
        new_tail = selected_png_setup["new_tail"]


        # general_output_folder_mod = general_output_folder.replace("tiff", key_png_setup)
        general_output_folder_mod = general_output_folder

        input_folder = fn05.build_str_input_folder_OneDay_nc2tiff(general_input_folder, selected_gregorian_date_SEP,
                                                        sat_prod = sat_prod)
        
        output_folder = input_folder.replace(general_input_folder, 
                                            general_output_folder_mod)




        convert_LSTF_nc2tiff_gen02(input_folder, output_folder, new_tail, tell_me = True)
        
    return



