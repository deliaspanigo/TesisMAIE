## Cargar el entorno de python
# source tesis_v004/bin/activate

## Desactivar el entorno de python
# deactivate


# Librerias
import sys
import os
import time

# Import own libreries
fn_folder = '01.own_resources/01.python_code/01.functions/'
sys.path.append(fn_folder)

# Common resources
import fn02_time as fn02

# Especial functions
import fn067_01_goes16_spi067_LSTF_download as fn067_01
import fn067_02_goes16_spi067_LSTF_convert_nc2tiff as fn067_02
import fn067_03_goes16_spi067_LSTF_convert_nc2png_OrigProj_v01  as fn067_03_v01
import fn067_03_goes16_spi067_LSTF_convert_nc2png_OrigProj_v02  as fn067_03_v02
import fn067_04_goes16_spi067_LSTF_convert_nc2png_WGS84Proj_v01 as fn067_04_v01
import fn067_04_goes16_spi067_LSTF_convert_nc2png_WGS84Proj_v02 as fn067_04_v02
import fn067_05_goes16_spi067_LSTF_convert_tiff2png_WGS84_v01   as fn067_05_v01
import fn067_06_goes16_spi067_LSTF_convert_nc2png2mp4   as fn067_06
import fn067_07_goes16_spi067_LSTF_convert_tiff2png2mp4 as fn067_07



def Process_goes16_spi067_LSTF_gen02_Proc01_OneDay_HardCoded(gregorian_date):


    print("Start: Process_goes16_spi067_LSTF_gen02_Proc01_OneDay_HardCoded()")
    print(f"Gregorian Date:{gregorian_date}")

    # nc2tiff
    if True:
        key_tiff_setup = "f00"
        fn067_02.convert_nc2tiff_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date, key_tiff_setup)
        print("\n")
    
    
    if True:    
        fn067_03_v01.convert_goes16_spi067_LSTF_nc2png_OrigProj_v01_gen02_OneDay_HardCoded(gregorian_date)
        fn067_03_v02.convert_goes16_spi067_LSTF_nc2png_OrigProj_v02_gen02_OneDay_HardCoded(gregorian_date)
        print("\n")
    
                
    if True:    
        fn067_04_v01.convert_goes16_spi067_LSTF_nc2png_WGS84Proj_v01_gen02_OneDay_HardCoded(gregorian_date)
        fn067_04_v02.convert_goes16_spi067_LSTF_nc2png_WGS84Proj_v02_gen02_OneDay_HardCoded(gregorian_date)
        print("\n")    
        
        
    # Gregorian date
    if True:
        
        # dom000_FullDisk
        key_png_setup = "f00A"
        fn067_05_v01.convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen02_OneDay_HardCoded(gregorian_date, key_png_setup)
        print("\n")
        
        # dom001_Latam
        key_png_setup = "f01A"
        fn067_05_v01.convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen02_OneDay_HardCoded(gregorian_date, key_png_setup)
        print("\n")
                
        # dom002_Arg
        key_png_setup = "f02A"
        fn067_05_v01.convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen02_OneDay_HardCoded(gregorian_date, key_png_setup)
        print("\n")

        key_png_setup = "f02B"
        fn067_05_v01.convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen02_OneDay_HardCoded(gregorian_date, key_png_setup)
        print("\n")

    if True:
        fn067_06.convert_nc2png2mp4_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date)
        print("\n")

    if True:
        fn067_07.convert_tiff2png2mp4_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date)
        print("\n")
        
        

    print("Close: Process_goes16_spi067_LSTF_gen02_pngComplet_OneDay_HardCoded()")
    
    return
    


def Process_goes16_spi067_LSTF_gen02_Proc02_OneDay_HardCoded(gregorian_date):

    tiempo_inicio = time.time()
    
    print("Start: Process_goes16_spi067_LSTF_gen02_Proc01_OneDay_HardCoded()")
    print(f"Gregorian Date:{gregorian_date}")

    # nc2tiff
    if True:
        key_tiff_setup = "f00"
        fn067_02.convert_nc2tiff_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date, key_tiff_setup)
        print("\n")
    
    
    if True:    
        fn067_03_v01.convert_goes16_spi067_LSTF_nc2png_OrigProj_v01_gen02_OneDay_HardCoded(gregorian_date)
        fn067_03_v02.convert_goes16_spi067_LSTF_nc2png_OrigProj_v02_gen02_OneDay_HardCoded(gregorian_date)
        print("\n")
    
                
    if False:  ###  
        fn067_04_v01.convert_goes16_spi067_LSTF_nc2png_WGS84Proj_v01_gen02_OneDay_HardCoded(gregorian_date)
        fn067_04_v02.convert_goes16_spi067_LSTF_nc2png_WGS84Proj_v02_gen02_OneDay_HardCoded(gregorian_date)
        print("\n")    
        
        
    # Gregorian date
    if True:
        
        # dom000_FullDisk
        key_png_setup = "f00A"
        fn067_05_v01.convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen02_OneDay_HardCoded(gregorian_date, key_png_setup)
        print("\n")
        
        # dom001_Latam
        key_png_setup = "f01A"
        fn067_05_v01.convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen02_OneDay_HardCoded(gregorian_date, key_png_setup)
        print("\n")
                
        # dom002_Arg
        key_png_setup = "f02A"
        fn067_05_v01.convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen02_OneDay_HardCoded(gregorian_date, key_png_setup)
        print("\n")

        key_png_setup = "f02B"
        fn067_05_v01.convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen02_OneDay_HardCoded(gregorian_date, key_png_setup)
        print("\n")
        
        
    if True:
        fn067_06.convert_nc2png2mp4_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date)
        print("\n")

    if True:
        fn067_07.convert_tiff2png2mp4_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date)
        print("\n")
        
        

    print("Close: Process_goes16_spi067_LSTF_gen02_pngComplet_OneDay_HardCoded()")
    
    
    # Tiempo
    tiempo_fin = time.time()
    # Calcular el tiempo transcurrido
    tiempo_transcurrido = tiempo_fin - tiempo_inicio

    print(f"El proceso tomó {tiempo_transcurrido:.5f} segundos.")
    
    return
    
        

def Process_goes16_spi067_LSTF_gen03_Proc02_OneDay_HardCoded(gregorian_date):

    tiempo_inicio = time.time()
    
    print("Start: Process_goes16_spi067_LSTF_gen03_Proc01_OneDay_HardCoded()")
    print(f"Gregorian Date:{gregorian_date}")

    # nc2tiff
    if True:
        key_tiff_setup = "f00"
        fn067_02.convert_nc2tiff_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date, key_tiff_setup)
        print("\n")
    
    
    if True:    
        fn067_03_v01.convert_goes16_spi067_LSTF_nc2png_OrigProj_v01_gen03_OneDay_HardCoded(gregorian_date)
        fn067_03_v02.convert_goes16_spi067_LSTF_nc2png_OrigProj_v02_gen03_OneDay_HardCoded(gregorian_date)
        print("\n")
    
                
    if False:  ###  
        fn067_04_v01.convert_goes16_spi067_LSTF_nc2png_WGS84Proj_v01_gen02_OneDay_HardCoded(gregorian_date)
        fn067_04_v02.convert_goes16_spi067_LSTF_nc2png_WGS84Proj_v02_gen02_OneDay_HardCoded(gregorian_date)
        print("\n")    
        
        
    # Gregorian date
    if True:
        
        # dom000_FullDisk
        key_png_setup = "f00A"
        fn067_05_v01.convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen03_OneDay_HardCoded(gregorian_date, key_png_setup)
        print("\n")
        
        # dom001_Latam
        key_png_setup = "f01A"
        fn067_05_v01.convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen03_OneDay_HardCoded(gregorian_date, key_png_setup)
        print("\n")
                
        # dom002_Arg
        key_png_setup = "f02A"
        fn067_05_v01.convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen03_OneDay_HardCoded(gregorian_date, key_png_setup)
        print("\n")

        key_png_setup = "f02B"
        fn067_05_v01.convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen03_OneDay_HardCoded(gregorian_date, key_png_setup)
        print("\n")
        
        key_png_setup = "f02C"
        fn067_05_v01.convert_goes16_spi067_LSTF_tiff2png_WGS84Proj_v01_gen03_OneDay_HardCoded(gregorian_date, key_png_setup)
        print("\n")
        
    if True:
        fn067_06.convert_nc2png2mp4_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date)
        print("\n")

    if True:
        fn067_07.convert_tiff2png2mp4_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date)
        print("\n")
        
        

    print("Close: Process_goes16_spi067_LSTF_gen02_pngComplet_OneDay_HardCoded()")
    
    
    # Tiempo
    tiempo_fin = time.time()
    # Calcular el tiempo transcurrido
    tiempo_transcurrido = tiempo_fin - tiempo_inicio

    print(f"El proceso tomó {tiempo_transcurrido:.5f} segundos.")
    
    return
    
                