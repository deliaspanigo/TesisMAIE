# # # Own functions
import fn01_generic as fn01
import fn02_time as fn02
import fn05_str_paths_spected as fn05

# Convertion n2 to tiff only for LSTF product.


# Librerias
import rioxarray as rxr
from itertools import compress
import os
import GOES

import xarray as xr
import rasterio
from rasterio.transform import from_origin
from rasterio.enums import Resampling
import pyproj


# File .nc Original projection on K
def setup_goes16_spi067_LSTF_convert_nc2tiff(selected_setup):
    principal_dic = {
        "f00": {
            "product_name": "ABI-L2-LSTF",
            "original_format": ".nc",
            "new_format": ".tiff",
            "new_tail": "_spi067_wgs84Proj_nc2tiff.tiff",
            "prefix_file_name" : "OR_ABI-L2-LSTF",
            "subfolder_prod_info": "spi067_ABI-L2-LSTF/",
            "subfolder_version": "",
            "abrev_name": "LST",
            "unit_var": "C",
            "domain": None,
            "input_folder": "02.download_goes16_OrigProj_nc_files/",
            "output_folder": "03.geot_goes16_wgs84Proj_tiff_files/",
            "overwrite": False 
            
        } 

            

    }

    return principal_dic[selected_setup]


# .nc to tiff
def convert_nc2tiff_goes16_spi067_LSTF_gen01(input_path, output_path, domain):

    print("Start: convert_nc2tiff_goes16_spi067_LSTF_gen01()")
    
    # Se establece el la referencia espacial y se define en el archivo
    selected_epsg = "EPSG:4326"
    spatial_ref = 'PROJCS["unnamed",GEOGCS["unknown",DATUM["unnamed",SPHEROID["Spheroid",6378137,298.2572221]],PRIMEM["Greenwich",0],UNIT["degree",0.0174532925199433,AUTHORITY["EPSG","9122"]]],PROJECTION["Geostationary_Satellite"],PARAMETER["central_meridian",-75],PARAMETER["satellite_height",35786023],PARAMETER["false_easting",0],PARAMETER["false_northing",0],UNIT["metre",1,AUTHORITY["EPSG","9001"]],AXIS["Easting",EAST],AXIS["Northing",NORTH],EXTENSION["PROJ4","+proj=geos +lon_0=-75 +h=35786023 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs +sweep=x"]]'

 
    
    # Open .nc file
    new_tiff = rxr.open_rasterio(input_path, mask_and_scale=True)

    
    # General changes
    new_tiff = new_tiff.rio.set_crs(spatial_ref)         # CRS
    new_tiff = new_tiff.rio.reproject(selected_epsg) # EPSG
    new_tiff = new_tiff.astype(float)  # Float 64 para todas las bandas
    new_tiff = new_tiff.rio.write_crs(selected_epsg, inplace=True)  # 
    

    
    # Selected band changes
    new_tiff['LST'][0] = new_tiff['LST'][0] - 273.15   # Pasamos de Kelvin a Celcius
    new_tiff['LST'][0] = new_tiff['LST'][0].fillna(-9999)

    new_tiff['LST'].attrs["units"] = "C"
    
    if domain is not None:
        # # Clip por bbox
        new_tiff['LST'] = new_tiff['LST'].rio.clip_box(
            minx=domain[0],
            miny=domain[2],
            maxx=domain[1],
            maxy=domain[3],
            crs=selected_epsg,
        )

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    new_tiff.LST.rio.to_raster(output_path)

    
    
    
    # nc_mod
    # nc_original.close()
    new_tiff.close()
    
    print("Close: convert_nc2tiff_goes16_spi067_LSTF_gen01()")
    return




def convert_nc2tiff_goes16_spi067_LSTF_gen02_OneDay_Simple(input_folder, output_folder, gregorian_date, overwrite, key_tiff_setup):

    print("Start: convert_nc2tiff_goes16_spi067_LSTF_gen02_OneDay_Simple()")
    
    # Import setup parameters
    # key_tiff_setup = "f00"
    selected_tiff_setup = setup_goes16_spi067_LSTF_convert_nc2tiff(key_tiff_setup)
    domain = selected_tiff_setup["domain"]
    
    input_paths, output_paths = fn05.generator_input_and_output_paths_nc2tiff_OnlyOneBand(selected_tiff_setup, input_folder, output_folder, gregorian_date)
   
 
    # Stock
    total_files = len(input_paths)

    # For each input file...
    for x in range(total_files):
        
        selected_input_path = input_paths[x]
        selected_output_path = output_paths[x]
        
        dt_exists = os.path.exists(selected_output_path)
        if dt_exists: 
            new_detail = "File exists!"
        elif not dt_exists:
            new_detail = "In progress..."
            
        print(f'Convertion... Init nc2tiff {x+1} of {total_files} - {new_detail}')

        if not dt_exists or overwrite:
            convert_nc2tiff_goes16_spi067_LSTF_gen01(selected_input_path, selected_output_path, domain)
        
        print("\n")
        
    print("Close: convert_nc2tiff_goes16_spi067_LSTF_gen02_OneDay_Simple()")
    
    return






def convert_nc2tiff_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date = None, key_tiff_setup = None):
    
    print('Start: convert_nc2tiff_goes16_spi067_LSTF_gen02_OneDay_HardCoded()')
    selected_tiff_setup = setup_goes16_spi067_LSTF_convert_nc2tiff(key_tiff_setup)
    
    # User info - Hardcoded
    input_folder = selected_tiff_setup["input_folder"]
    output_folder  = selected_tiff_setup["output_folder"] 
    overwrite = selected_tiff_setup["overwrite"]
    
    
    # Create folder
    fn01.create_folder_if_not_exists(output_folder)
    
    # Download - gen02
    convert_nc2tiff_goes16_spi067_LSTF_gen02_OneDay_Simple(input_folder, output_folder, gregorian_date, overwrite, key_tiff_setup)

    print('Close: convert_nc2tiff_goes16_spi067_LSTF_gen02_OneDay_HardCoded()')
    
    return










