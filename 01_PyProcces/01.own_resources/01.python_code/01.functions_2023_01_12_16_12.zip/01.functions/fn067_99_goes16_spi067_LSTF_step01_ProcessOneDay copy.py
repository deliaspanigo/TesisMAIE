## Cargar el entorno de python
# source tesis_v004/bin/activate

## Desactivar el entorno de python
# deactivate


# Librerias
import sys
import os

# Import own libreries
fn_folder = '01.own_resources/01.python_code/01.functions/'
sys.path.append(fn_folder)

# Common resources
import fn02_time as fn02

# Especial functions
import fn067_01_goes16_spi067_LSTF_download as fn067_01
import fn067_02_goes16_spi067_LSTF_convert_nc2tiff as fn067_02
import fn067_03_goes16_spi067_LSTF_convert_nc2png_OrigProj_v01  as fn067_03_v01
import fn067_03_goes16_spi067_LSTF_convert_nc2png_OrigProj_v02  as fn067_03_v02
import fn067_04_goes16_spi067_LSTF_convert_nc2png_WGS84Proj_v01 as fn067_04_v01
import fn067_04_goes16_spi067_LSTF_convert_nc2png_WGS84Proj_v02 as fn067_04_v02
import fn067_05_goes16_spi067_LSTF_convert_tiff2png_WGS84_v01   as fn067_05_v01
import fn067_06_goes16_spi067_LSTF_convert_nc2png2mp4   as fn067_06
import fn067_07_goes16_spi067_LSTF_convert_tiff2png2mp4 as fn067_07



def Process_goes16_spi067_LSTF_gen02_dom000_pngComplet_OneDay_HardCoded(gregorian_date):
    # Selected day
    # gregorian_date = fn02.get_current_date_gregorianCOMP()
    # gregorian_date = "20230101"

    print("Start: Process_goes16_spi067_LSTF_gen02_dom000_pngComplet_OneDay_HardCoded()")
    print(f"Gregorian Date:{gregorian_date}")
    # 01) Download - gen02
    # if False:
    #     fn067_01.download_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date = gregorian_date)

    # Format: Total View
    special_key = "f01"
    
    # 02) nc2png

    
    if False:
        fn067_02_v01.convert_nc2png_goes16_spi067_LSTF_v01_gen02_OneDay_HardCoded(gregorian_date = gregorian_date )
        print("\n")
        fn067_02_v02.convert_nc2png_goes16_spi067_LSTF_v02_gen02_OneDay_HardCoded(gregorian_date = gregorian_date )
        print("\n")
        fn067_02_v03.convert_nc2png_goes16_spi067_LSTF_v03_gen02_OneDay_HardCoded(gregorian_date = gregorian_date )
        print("\n")
        fn067_02_v04.convert_nc2png_goes16_spi067_LSTF_v04_gen02_OneDay_HardCoded(gregorian_date = gregorian_date )
        print("\n")
        
    # 03) nc2png2mp4
    if False:
        fn067_03.convert_nc2png2mp4_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date = gregorian_date)
        print("\n")
        
    # 04) nc2tiff   
    if True:
        fn067_04.convert_nc2tiff_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date = gregorian_date, key_tiff_setup = special_key)
        print("\n")
        
    # 05) tiff2png    
    if True:
        fn067_05_v01.convert_tiff2png_goes16_spi067_LSTF_v01_gen02_OneDay_HardCoded(gregorian_date = gregorian_date, key_png_setup = special_key)
        print("\n")
        
    # 06) tiff2png2mp4    
    if False:
        fn067_06.convert_tiff2png2mp4_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date = gregorian_date)
        print("\n")
    
    print("Close: Process_goes16_spi067_LSTF_gen02_OneDay_HardCoded_dom01()")
    
    return
    
    