## Cargar el entorno de python
# source tesis_v004/bin/activate

## Desactivar el entorno de python
# deactivate


# Librerias
import sys
import os
import time

# Import own libreries
fn_folder = '01.own_resources/01.python_code/01.functions/'
sys.path.append(fn_folder)

# Common resources
import fn02_time as fn02

# Especial functions
import fn067_01_goes16_spi067_LSTF_download as fn067_01
import fn067_02_goes16_spi067_LSTF_convert_nc2tiff as fn067_02

import fn067_03_goes16_spi067_LSTF_ppi001_convert_nc2png_v001_OrigProj_Kelvin as fn067_03_ppi001

import fn067_03_goes16_spi067_LSTF_ppi002_convert_nc2png_v002_OrigProj_Celcius  as fn067_03_ppi002
import fn067_03_goes16_spi067_LSTF_ppi003_convert_tiff2png_v001_WGS84_Celcius   as fn067_03_ppi003
import fn067_03_goes16_spi067_LSTF_ppi004_convert_tiff2png_v001_WGS84_Celcius   as fn067_03_ppi004
import fn067_03_goes16_spi067_LSTF_ppi005_convert_tiff2png_v001_WGS84_Celcius   as fn067_03_ppi005

import fn067_03_goes16_spi067_LSTF_ppi010_convert_nc2png_v003_WGS84Proj_Kelvin  as fn067_03_ppi010
import fn067_03_goes16_spi067_LSTF_ppi011_convert_nc2png_v004_WGS84Proj_Celcius as fn067_03_ppi011

import fn067_04_goes16_spi067_LSTF_convert_png2mp4 as fn067_04



# 5 minutos 30 - Version special_prod = False
# input: 24 .nc
# output: 
# 24 x 1 =  24 tiff
# 24 x 5 = 120 png
#  1 x 5 =   5 mp4
def PROCESS_goes16_spi067_LSTF_gen02Full_OneDay_HardCoded(gregorian_date, special_prod = False):


    print("PROCESS_goes16_spi067_LSTF_gen02Full_OneDay_HardCoded()")
    print(f"Gregorian Date:{gregorian_date}")

    # 1) Download
    # No lo realizamos aqui.
    
    # 2) Convert - nc2tiff
    if True:
        fn067_02.convert_nc2tiff_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date, key_tiff_setup = "f00")
        print("\n")
    
    
    if True:
        fn067_03_ppi001.convert_goes16_spi067_ppi001_gen02_OneDay_HardCoded(gregorian_date)
        print("\n")
        
    if True:    
        fn067_03_ppi002.convert_goes16_spi067_ppi002_gen02_OneDay_HardCoded(gregorian_date)
    
    if True:    
        fn067_03_ppi003.convert_goes16_spi067_ppi003_gen02_OneDay_HardCoded(gregorian_date, key_png_setup = "dom000")
        fn067_03_ppi003.convert_goes16_spi067_ppi003_gen02_OneDay_HardCoded(gregorian_date, key_png_setup = "dom001")
        fn067_03_ppi003.convert_goes16_spi067_ppi003_gen02_OneDay_HardCoded(gregorian_date, key_png_setup = "dom002")

    if True:   # Solo ARG  
        fn067_03_ppi004.convert_goes16_spi067_ppi004_gen02_OneDay_HardCoded(gregorian_date, key_png_setup = "dom002")
                
    if True:   # Solo ARG   
       fn067_03_ppi005.convert_goes16_spi067_ppi005_gen02_OneDay_HardCoded(gregorian_date, key_png_setup = "dom002")
        
    if special_prod:    
        fn067_03_ppi010.convert_goes16_spi067_ppi010_gen02_OneDay_HardCoded(gregorian_date)

    if special_prod:    
        fn067_03_ppi011.convert_goes16_spi067_ppi011_gen02_OneDay_HardCoded(gregorian_date)
        
     
    # 4) png2mp4 - OneDay
    if True:
        fn067_04.convert_png2mp4_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date)
    
        
    
        
        

    print("Close: PROCESS_goes16_spi067_LSTF_gen02Full_OneDay_HardCoded()")
    
    return
    



def PROCESS_goes16_spi067_LSTF_gen03Full_OneDay_HardCoded(gregorian_date, special_prod = False):


    print("PROCESS_goes16_spi067_LSTF_gen03Full_OneDay_HardCoded()")
    print(f"Gregorian Date:{gregorian_date}")

    # 1) Download
    # No lo realizamos aqui.
    
    # 2) Convert - nc2tiff
    if True:
        fn067_02.convert_nc2tiff_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date, key_tiff_setup = "f00")
        print("\n")
    
    
    if True:
        fn067_03_ppi001.convert_goes16_spi067_ppi001_gen03_OneDay_HardCoded(gregorian_date)
        print("\n")
        
    if True:    
        fn067_03_ppi002.convert_goes16_spi067_ppi002_gen03_OneDay_HardCoded(gregorian_date)
    
    if True:    
        fn067_03_ppi003.convert_goes16_spi067_ppi003_gen03_OneDay_HardCoded(gregorian_date, key_png_setup = "dom000")
        fn067_03_ppi003.convert_goes16_spi067_ppi003_gen03_OneDay_HardCoded(gregorian_date, key_png_setup = "dom001")
        fn067_03_ppi003.convert_goes16_spi067_ppi003_gen03_OneDay_HardCoded(gregorian_date, key_png_setup = "dom002")

    if True:   # Solo ARG
       fn067_03_ppi004.convert_goes16_spi067_ppi004_gen03_OneDay_HardCoded(gregorian_date, key_png_setup = "dom002")
                
    if True:   # Solo ARG
        fn067_03_ppi005.convert_goes16_spi067_ppi005_gen03_OneDay_HardCoded(gregorian_date, key_png_setup = "dom002")
        
    if special_prod:    
        fn067_03_ppi010.convert_goes16_spi067_ppi010_gen03_OneDay_HardCoded(gregorian_date)

    if special_prod:    
        fn067_03_ppi011.convert_goes16_spi067_ppi011_gen03_OneDay_HardCoded(gregorian_date)
        
     
       # 4) png2mp4 - OneDay
    if True:
        fn067_04.convert_png2mp4_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date)
      
    
        
        

    print("Close: PROCESS_goes16_spi067_LSTF_gen03Full_OneDay_HardCoded()")
    
    return
    


# 3 minutos 40 - Version special_prod = False
# input: 24 .nc
# output: 
# 24 x 1 =  24 tiff
# 24 x 5 = 120 png
#  1 x 5 =   5 mp4
def PROCESS_goes16_spi067_LSTF_genMIX_OneDay_HardCoded(gregorian_date, special_prod = False):


    print("PROCESS_goes16_spi067_LSTF_genMIX_OneDay_HardCoded()")
    print(f"Gregorian Date:{gregorian_date}")

    # 1) Download
    # No lo realizamos aqui.
    
    # 2) Convert - nc2tiff
    if True:
        fn067_02.convert_nc2tiff_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date, key_tiff_setup = "f00")
        print("\n")
    
    
    if True:
        fn067_03_ppi001.convert_goes16_spi067_ppi001_gen03_OneDay_HardCoded(gregorian_date)
        print("\n")
        
    if True:    
        fn067_03_ppi002.convert_goes16_spi067_ppi002_gen03_OneDay_HardCoded(gregorian_date)
    
    if True:    
        fn067_03_ppi003.convert_goes16_spi067_ppi003_gen03_OneDay_HardCoded(gregorian_date, key_png_setup = "dom000")
        fn067_03_ppi003.convert_goes16_spi067_ppi003_gen03_OneDay_HardCoded(gregorian_date, key_png_setup = "dom001")
        fn067_03_ppi003.convert_goes16_spi067_ppi003_gen03_OneDay_HardCoded(gregorian_date, key_png_setup = "dom002")

    if True:   # Solo ARG
        fn067_03_ppi004.convert_goes16_spi067_ppi004_gen03_OneDay_HardCoded(gregorian_date, key_png_setup = "dom002")
                
    if True:   # Solo ARG
        fn067_03_ppi005.convert_goes16_spi067_ppi005_gen03_OneDay_HardCoded(gregorian_date, key_png_setup = "dom002")
        
    if special_prod:    
        fn067_03_ppi010.convert_goes16_spi067_ppi010_gen02_OneDay_HardCoded(gregorian_date)

    if special_prod:    
        fn067_03_ppi011.convert_goes16_spi067_ppi011_gen02_OneDay_HardCoded(gregorian_date)
        
     
       # 4) png2mp4 - OneDay
    if True:
        fn067_04.convert_png2mp4_goes16_spi067_LSTF_gen02_OneDay_HardCoded(gregorian_date)
      
    
        
        

    print("Close: PROCESS_goes16_spi067_LSTF_genMIX_OneDay_HardCoded()")
    
    return
    

