
# 01) Download LSTF
# 02) Convert nc2png
# 03) Convert nc2tiff
# 04) Convert tiff2png
# 05) Convert png2gif
# 06) Convert png2mp4

# Own libreries
import fn01_generic as fn01
import fn02_time as fn02

# # # Libreries
# Libreries
import os
import GOES



# MCMIPF - download



def download_goes_spi076_MCMIPF_gen01(sat_prod = None, gregorian_date = None, output_folder = None, time_init = "000000", time_fin = "235959"):
    
    datetimeini = str(gregorian_date) + str("-") + str(time_init)
    datetimefin = str(gregorian_date) + str("-") + str(time_fin)
        
    GOES.download(Satellite='goes16',  Product=sat_prod,     
            DateTimeIni = datetimeini, DateTimeFin = datetimefin, 
            channel = ['01','02','03'], 
            rename_fmt = '%Y%m%d%H%M%S', 
            path_out=output_folder,
            retries = 10,
            backoff = 10,
            size_format = 'Decimal',
            show_download_progress = True,
            overwrite_file = False)

    
    return


def download_goes16_spi076_MCMIPF_gen02_OneDay_Simple(gregorian_date = None, general_output_folder = None):

    print('Start: download_goes16_spi076_MCMIPF_gen02_OneDay_Simple()')
    
    # User specification - Hardcoded
    sat_name = "goes16" 
    sat_prod = "ABI-L2-MCMIPF"
    subfolder_prod_info = "spi076_ABI-L2-MCMIPF/"
    abrev_prod = "MCMIPF"
    
    # Subfolder for date
    subfolder_date = fn02.gregorianCOMP_to_newsubfolder(gregorian_date_str = gregorian_date)
    
    # Output folder structure
    output_folder = general_output_folder + subfolder_prod_info + subfolder_date
    fn01.create_folder_if_not_exists(output_folder)
    
    
    the_time01 = ["000000", "010000", "020000", "030000", "040000",
            "050000", "060000", "070000", "080000", "090000",
            "100000", "110000", "120000", "130000", "140000",
            "150000", "160000", "170000", "180000", "190000",
            "200000", "210000", "220000", "230000"]

    the_time02 = ["000040", "010040", "020040", "030040", "040040",
                "050040", "060040", "070040", "080040", "090040",
                "100040", "110040", "120040", "130040", "140040",
                "150040", "160040", "170040", "180040", "190040",
                "200040", "210040", "220040", "230040"]
    
    
    total_files = len(the_time01)
    
    for x in range(total_files):
        
        print(f"{sat_name} - {abrev_prod} - {x+1} of {total_files}")
        
        time_init =  the_time01[x]
        time_fin  =  the_time02[x]
        
        download_goes_spi076_MCMIPF_gen01(sat_prod = sat_prod,
                                 gregorian_date = gregorian_date, 
                                 output_folder = output_folder, 
                                 time_init = time_init, 
                                 time_fin = time_fin)
    
        print("\n")
        
    print('Close: download_goes16_spi076_MCMIPF_gen02_OneDay_Simple()')


    return






def download_goes16_spi076_MCMIPF_gen02_OneDay_HardCoded(gregorian_date = None):
    
    print('Start: download_goes16_spi076_MCMIPF_gen02_OneDay_HardCoded()')
        
    # User info - Hardcoded
    general_output_folder = "02.download_goes16_OrigProj_nc_files/"
    
    # Create folder
    fn01.create_folder_if_not_exists(general_output_folder)
    
    # Download - gen02
    download_goes16_spi076_MCMIPF_gen02_OneDay_Simple(gregorian_date = gregorian_date, general_output_folder = general_output_folder)

    print('Close: download_goes16_spi076_MCMIPF_gen02_OneDay_HardCoded()')
    
    return




def download_goes16_spi076_MCMIPF_gen02_RangeDate_HardCoded(init_gregorian_date, end_gregorian_date):
    
    print('Start: download_goes16_spi076_MCMIPF_gen02_RangeDate_HardCoded()')
    
    gregorian_list = fn02.generate_gregorian_date_list(start_date = init_gregorian_date, end_date = end_gregorian_date)

    for x in gregorian_list:
        download_goes16_spi076_MCMIPF_gen02_OneDay_HardCoded(gregorian_date = x)
        
    print('Close: download_goes16_spi076_MCMIPF_gen02_RangeDate_HardCoded()')
     
    return

